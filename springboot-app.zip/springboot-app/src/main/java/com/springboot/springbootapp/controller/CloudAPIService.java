package com.springboot.springbootapp.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.springbootapp.model.CloudVendor;

@RestController
@RequestMapping("/cloudvendor")
public class CloudAPIService {
	public CloudVendor getCloudVendorDetails(String vendorId)
	{
		return new CloudVendor("C1","Vendor 1","Add1","1010101010");
	}
}
