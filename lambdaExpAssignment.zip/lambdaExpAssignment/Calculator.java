package lambdaExpAssignment;
@FunctionalInterface
interface ArithmeticOperation {
    double operate(double num1, double num2);
}
public class Calculator {
	public static void main(String[] args) {
        // Example usage
        double operand1 = 10;
        double operand2 = 5;

        // Addition
        double resultAdd = performOperation((num1, num2) -> num1 + num2, operand1, operand2);
        System.out.println("Addition: " + resultAdd);

        // Subtraction
        double resultSubtract = performOperation((num1, num2) -> num1 - num2, operand1, operand2);
        System.out.println("Subtraction: " + resultSubtract);

        // Multiplication
        double resultMultiply = performOperation((num1, num2) -> num1 * num2, operand1, operand2);
        System.out.println("Multiplication: " + resultMultiply);

        // Division
        double resultDivide = performOperation((num1, num2) -> {
            if (num2 != 0) {
                return num1 / num2;
            } else {
                System.out.println("Error: Cannot divide by zero");
                return Double.NaN; // Not a Number
            }
        }, operand1, operand2);
        System.out.println("Division: " + resultDivide);
    }

    private static double performOperation(ArithmeticOperation operation, double num1, double num2) {
        return operation.operate(num1, num2);
    }
}
