package assignment1;

import java.util.Scanner;

public class TaxSlab {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Enter your annual income:");
	        double income = scanner.nextDouble();

	        double taxAmount = calculateIncomeTax(income);
	        
	        System.out.println("Income: " + income);
	        System.out.println("Tax Amount: " + taxAmount);

	        
	    }

	    private static double calculateIncomeTax(double income) {
	        double taxAmount = 0;

	        	if(income <0) {
	        		System.out.println("Invalid Input");
	            	System.exit(0);
	        	}
	        		
	        	else if (income <= 180000) 
	                taxAmount = 0;
	            
	            else if (income <= 300000) 
	                taxAmount = (income - 180000) * 0.1;
	            
	            else if (income <= 500000) 
	                taxAmount = (300000 - 180000) * 0.1 + (income - 300000) * 0.2;
	           
	            else
	                taxAmount = (300000 - 180000) * 0.1 + (500000 - 300000) * 0.2 + (income - 500000) * 0.3;
	            
	            

	        return taxAmount;
	    }
}
