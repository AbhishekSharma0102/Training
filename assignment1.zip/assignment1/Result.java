package assignment1;

import java.util.Scanner;

public class Result {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter marks for Subject 1:");
        int subject1 = scanner.nextInt();
        
        System.out.println("Enter marks for Subject 2:");
        int subject2 = scanner.nextInt();

        System.out.println("Enter marks for Subject 3:");
        int subject3 = scanner.nextInt();
        if ((subject1 >100 || subject1 <0)||(subject2 >100 || subject2 <0)||(subject3 >100 || subject3 <0)){
        	System.out.println("Invalid Input");
        	System.exit(0);
        }
        if (subject1 >= 60 && subject2 >= 60 && subject3 >= 60) {
            System.out.println("Result: Passed");
        } else if ((subject1 >= 60 && subject2 >= 60) || (subject2 >= 60 && subject3 >= 60) || (subject1 >= 60 && subject3 >= 60)) {
            System.out.println("Result: Promoted");
        } else if (subject1 >= 60 || subject2 >= 60 || subject3 >= 60) {
            System.out.println("Result: Failed");
        } else {
            System.out.println("Result: Failed (All subjects marks are less than 60)");
        }

       
    }
}
